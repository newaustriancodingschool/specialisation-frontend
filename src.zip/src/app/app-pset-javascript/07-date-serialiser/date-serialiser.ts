export const dateSerialiser = {
  serialise: function(anObject, type): string {
    return '';
  },
  deserialise: function(json): any {

  }
};
