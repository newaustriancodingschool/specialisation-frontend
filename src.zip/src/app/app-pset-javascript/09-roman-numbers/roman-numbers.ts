export const converter = {
  toArabic: function(roman): number {
    return 0;
  },
  toRoman: function(arabic): string {
    return '';
  }
}
