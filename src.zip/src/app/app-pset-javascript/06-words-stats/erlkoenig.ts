export const erlkoenig = '' +
  'Wer reitet so spät durch Nacht und Wind?\n' +
  'Es ist der Vater mit seinem Kind;\n' +
  'Er hat den Knaben wohl in dem Arm,\n' +
  'Er fasst ihn sicher, er hält ihn warm.\n' +
  '\n' +
  'Mein Sohn, was birgst du so bang dein Gesicht? –\n' +
  'Siehst, Vater, du den Erlkönig nicht?\n' +
  'Den Erlenkönig mit Kron’ und Schweif? –\n' +
  'Mein Sohn, es ist ein Nebelstreif. –\n' +
  '\n' +
  '„Du liebes Kind, komm, geh mit mir!\n' +
  'Gar schöne Spiele spiel’ ich mit dir;\n' +
  'Manch’ bunte Blumen sind an dem Strand,\n' +
  'Meine Mutter hat manch gülden Gewand.“ –\n' +
  '\n' +
  'Mein Vater, mein Vater, und hörest du nicht,\n' +
  'Was Erlenkönig mir leise verspricht? –\n' +
  'Sei ruhig, bleibe ruhig, mein Kind;\n' +
  'In dürren Blättern säuselt der Wind. –\n' +
  '\n' +
  '„Willst, feiner Knabe, du mit mir gehn?\n' +
  'Meine Töchter sollen dich warten schön;\n' +
  'Meine Töchter führen den nächtlichen Reihn\n' +
  'Und wiegen und tanzen und singen dich ein.“ –\n' +
  '\n' +
  'Mein Vater, mein Vater, und siehst du nicht dort\n' +
  'Erlkönigs Töchter am düstern Ort? –\n' +
  'Mein Sohn, mein Sohn, ich seh’ es genau:\n' +
  'Es scheinen die alten Weiden so grau. –\n' +
  '\n' +
  '„Ich liebe dich, mich reizt deine schöne Gestalt;\n' +
  'Und bist du nicht willig, so brauch’ ich Gewalt.“ –\n' +
  'Mein Vater, mein Vater, jetzt faßt er mich an!\n' +
  'Erlkönig hat mir ein Leids getan! –\n' +
  '\n' +
  'Dem Vater grauset’s; er reitet geschwind,\n' +
  'Er hält in Armen das ächzende Kind,\n' +
  'Erreicht den Hof mit Mühe und Not;\n' +
  'In seinen Armen das Kind war tot.';
