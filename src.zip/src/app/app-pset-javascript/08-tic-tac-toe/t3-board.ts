export class T3Board {
  constructor(data) {

  }

  getStatus(): any {
  }
}
